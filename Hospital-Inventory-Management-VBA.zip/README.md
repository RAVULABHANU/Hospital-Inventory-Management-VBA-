# Hospital Inventory Management (VBA)

This project is an Excel VBA tool for managing hospital inventory. It:
- Loads inventory data
- Highlights items that are below the reorder level (marked in red)
- Helps ensure timely restocking of medical supplies

## Files
- `hospital_inventory.csv`: Sample hospital inventory data
- `Module1.bas`: VBA code module

## How to Use
1. Import `hospital_inventory.csv` into Excel in a sheet named `Inventory`
2. Add the VBA code (Module1.bas) to your Excel workbook
3. Run the macro `AnalyzeInventory` to highlight low-stock items
